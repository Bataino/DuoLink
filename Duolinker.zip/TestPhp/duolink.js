function duolink (windows7, windows10) {
	// body...
	console.log(navigator.oscpu);
	if (navigator.oscpu.indexOf("6.3") > 0) {
		console.log("Windows 8");
		location.href = windows7;

	}
}