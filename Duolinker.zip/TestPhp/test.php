<?php
	//echo 'sleep';
	$windows7 = 'gooogel.com';
	$windows10 = 'gooogle.com';
?>
	<html>
	<head>
		<title></title>
		<script type="text/javascript" src="duolink.js"></script>
	</head>
	<body>
		<button style="padding:10px;margin:20px;background:green;color:white;border:none;" 
			onclick="duolink('<?php echo $windows7;?>' , '<?php echo $windows10;?>');">
			download
		</button>
	</body>
	</html>

